/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v1.1.0-rc.5-master-26a5fb8
 */
goog.provide("ng.material.components.fabTrigger"),goog.require("ng.material.core"),function(){"use strict";function r(){return{restrict:"E",require:["^?mdFabSpeedDial","^?mdFabToolbar"]}}angular.module("material.components.fabTrigger",["material.core"]).directive("mdFabTrigger",r)}(),ng.material.components.fabTrigger=angular.module("material.components.fabTrigger");