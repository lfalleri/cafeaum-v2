/*!
 * AngularJS Material Design
 * https://github.com/angular/material
 * @license MIT
 * v1.1.6-master-81ad90f
 */
function MdTruncateDirective(){return{restrict:"AE",controller:MdTruncateController}}function MdTruncateController(e){e.addClass("md-truncate")}goog.provide("ngmaterial.components.truncate"),goog.require("ngmaterial.core"),MdTruncateController.$inject=["$element"],angular.module("material.components.truncate",["material.core"]).directive("mdTruncate",MdTruncateDirective),ngmaterial.components.truncate=angular.module("material.components.truncate");