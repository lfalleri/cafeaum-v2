/*!
 * AngularJS Material Design
 * https://github.com/angular/material
 * @license MIT
 * v1.1.6-master-81ad90f
 */
function getDirective(e){function i(e){function i(i,n,o){var c=e(o[t]);n.on(r,function(e){var t=e.currentTarget;i.$applyAsync(function(){c(i,{$event:e,$target:{current:t}})})})}return{restrict:"A",link:i}}i.$inject=["$parse"];var t="md"+e,r="$md."+e.toLowerCase();return i}goog.provide("ngmaterial.components.swipe"),goog.require("ngmaterial.core"),angular.module("material.components.swipe",["material.core"]).directive("mdSwipeLeft",getDirective("SwipeLeft")).directive("mdSwipeRight",getDirective("SwipeRight")).directive("mdSwipeUp",getDirective("SwipeUp")).directive("mdSwipeDown",getDirective("SwipeDown")),ngmaterial.components.swipe=angular.module("material.components.swipe");