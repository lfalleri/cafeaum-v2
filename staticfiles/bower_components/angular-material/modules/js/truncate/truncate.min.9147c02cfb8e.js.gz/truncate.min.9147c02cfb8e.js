/*!
 * AngularJS Material Design
 * https://github.com/angular/material
 * @license MIT
 * v1.1.6-master-81ad90f
 */
!function(t,e,n){"use strict";function r(){return{restrict:"AE",controller:c}}function c(t){t.addClass("md-truncate")}c.$inject=["$element"],e.module("material.components.truncate",["material.core"]).directive("mdTruncate",r)}(window,window.angular);