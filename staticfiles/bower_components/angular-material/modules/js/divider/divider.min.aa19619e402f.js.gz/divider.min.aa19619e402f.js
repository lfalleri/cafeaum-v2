/*!
 * AngularJS Material Design
 * https://github.com/angular/material
 * @license MIT
 * v1.1.6-master-81ad90f
 */
!function(i,e,n){"use strict";function r(i){return{restrict:"E",link:i}}r.$inject=["$mdTheming"],e.module("material.components.divider",["material.core"]).directive("mdDivider",r)}(window,window.angular);