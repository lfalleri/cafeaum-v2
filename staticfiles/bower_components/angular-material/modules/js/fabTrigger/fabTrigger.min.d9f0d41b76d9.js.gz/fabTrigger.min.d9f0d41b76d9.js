/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v1.1.0-rc.5-master-26a5fb8
 */
!function(r,e,i){"use strict";!function(){function r(){return{restrict:"E",require:["^?mdFabSpeedDial","^?mdFabToolbar"]}}e.module("material.components.fabTrigger",["material.core"]).directive("mdFabTrigger",r)}()}(window,window.angular);