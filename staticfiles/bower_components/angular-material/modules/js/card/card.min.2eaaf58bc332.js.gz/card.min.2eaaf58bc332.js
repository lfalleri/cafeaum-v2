/*!
 * AngularJS Material Design
 * https://github.com/angular/material
 * @license MIT
 * v1.1.6-master-81ad90f
 */
!function(n,i,t){"use strict";function e(n){return{restrict:"E",link:function(i,t,e){t.addClass("_md"),n(t)}}}e.$inject=["$mdTheming"],i.module("material.components.card",["material.core"]).directive("mdCard",e)}(window,window.angular);