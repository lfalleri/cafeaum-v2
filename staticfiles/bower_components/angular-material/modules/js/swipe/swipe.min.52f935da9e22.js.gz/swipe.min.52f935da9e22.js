/*!
 * AngularJS Material Design
 * https://github.com/angular/material
 * @license MIT
 * v1.1.6-master-81ad90f
 */
!function(e,i,t){"use strict";function n(e){function i(e){function i(i,r,c){var o=e(c[t]);r.on(n,function(e){var t=e.currentTarget;i.$applyAsync(function(){o(i,{$event:e,$target:{current:t}})})})}return{restrict:"A",link:i}}i.$inject=["$parse"];var t="md"+e,n="$md."+e.toLowerCase();return i}i.module("material.components.swipe",["material.core"]).directive("mdSwipeLeft",n("SwipeLeft")).directive("mdSwipeRight",n("SwipeRight")).directive("mdSwipeUp",n("SwipeUp")).directive("mdSwipeDown",n("SwipeDown"))}(window,window.angular);